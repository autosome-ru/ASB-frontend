Each file is the BAD map obtained for a cell type studied in a set of related expreiments (see Abramov et al. 2021 for details doi:10.1038/s41467-021-23007-0) using
BABACHI [https://github.com/autosome-ru/BABACHI] v1.5.6 with following parameters:
    --boundary-penalty=4
    --states=1,4/3,1.5,2,2.5,3,4,5,6
Each BAD map consists of segments along which BAD is considered constant. Each segment is described in a single line:
#chr: chromosome
start: segment start position (1-based)
end: segment end position (1-based, the position also corresponds to the segment)
BAD: BAD of the segment, takes values from (1, 4/3, 1.5, 2, 2.5, 3, 4, 5, 6)
QX: log-likelihood of the BAD value for the segment
SNP_count: the total number of SNPs in the segment
SNP_ID_count: the total number of unique SNPs in the segment
sum_cover: the total read coverage of all SNPs in the segment
